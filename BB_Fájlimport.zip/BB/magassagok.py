import os
os.system("cls")
print(" _______________________")
print("|Listaelemek beolvasása:|")
print("|_______________________|")
print("")
magas=[]
with open("magassagok.txt","r", encoding="utf-8") as fajl:
    for sor in fajl:
        magassag= int(sor.strip())
        magas.append(magassag)
print(magas)

#függvénnyel
ossz=sum(magas)
print("________________________________________")
print("A lista elemek összege: ", ossz)
print('A lista elemek átlaga: ', ossz/len(magas))
print("A lista legnagyobb eleme: ", max(magas))
print("A lista legkisebb eleme: ", min(magas))
print("")
input("Nyomj ENTER-t a fájlba írásához.")
print("________________________________________")
#Kiírás fájlba
with open("magassagok_kiir.txt", "w", encoding="utf-8") as kiir:
    kiir.write(f"A lista elemei: {magas}\n")
    kiir.write(f"A lista elemszáma: {len(magas)}\n")
    kiir.write(f"A lista elemek átlaga: {sum(magas)/len(magas)}\n")
    kiir.write(f"A lista legnagyobb eleme: {max(magas)}\n")
    kiir.write(f"A lista legkisebb eleme: {min(magas)}\n")
print("Az adatok fájlba írása megtörtént!")

    