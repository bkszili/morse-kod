import os
os.system("cls")
emberek=[]
with open("adatok.txt","r", encoding="utf-8") as beolvas:
    for sor in beolvas:
        nev, kor, fogl=sor.strip().split(";")
        emberek.append((nev, int(kor), fogl))
#vagy
    #egysor=sor.strip().split(";")
    #emberek.append(sor.trip().split(";"))
    #emberek.append((egysor[0], int(egysor[1]), egysor[2]))
#b,
print("Kiíratás listából")
print(emberek)
print()
with open("adatok_nyomtatasra.txt","w", encoding="utf-8") as kiir:
    for nev, kor, fogl in emberek:
        print(f"{nev} {kor} éves {fogl}.")
        kiir.write(f"{nev} {kor} éves {fogl}. \n")

#c,
print("--------------------------------------")
print("Írassuk ki a 40 év fölöttieket: ")
for nev, kor, fogl in emberek:
    if kor>40:
        print(f"Név: {nev} Kor: {kor}")
        
#d
#Listázzuk ki a tanulókat.
print("--------------------------------------")
print("Írassuk ki a tanulókat: ")
for nev,kor, fogl in emberek:
    if fogl=="tanuló":
        print(f"{nev} Foglalkozása: {fogl}")
    