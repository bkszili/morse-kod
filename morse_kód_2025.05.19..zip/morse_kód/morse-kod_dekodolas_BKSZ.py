import os
os.system("cls")

morse = {}

#fájl beolvasás
with open("morsekodok.txt", "r", encoding="UTF-8") as beolvas:
    for sor in beolvas:
        kod = sor.strip().split()
        if len(kod) == 2:
            betu, kod_morse = kod
            morse[betu] = kod_morse

#Fordított szótár a dekódoláshoz
morse_dekod = {}
for k in morse:
    v = morse[k]
    morse_dekod[v] = k

#Morse-kód megadása
morse_be = input("Kérek egy Morse-kódot, amit majd lefordíthatok egy szóra: ")

#A Morse-kód szavakra bontása
morse_szavak = morse_be.strip().split()

#Kiíratás
dekodolt_szo = ""
for kod in morse_szavak:
    if kod in morse_dekod:
        dekodolt_szo += morse_dekod[kod]
    else:
        print(f"{betu} Nincs ilyen kód a beolvasott fájlban")

print("A dekódolt szó:", dekodolt_szo)